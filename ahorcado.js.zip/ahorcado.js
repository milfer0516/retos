function indexOfLetters(wordArray, letter) {
 let indexOfLetter = []
 for (let i = 0; i < wordArray.length; i++){
   if (wordArray[i] == letter) {
     indexOfLetter.push(i)
   }
 }
 return indexOfLetter
}

function hangMan(){
let indexForWord = Math.floor(Math.random() * (5))
let correctGuess = []
let theMan = ''
const manError = ['|  o ', '\n| -', '0','-','\n| o',' o']
const wordsArray = ['python','patito','monday','gato','perro']
let wordInLetters = Array.from(wordsArray[indexForWord])
let error = 0
let correctLetters = wordInLetters.length

for (let i = 0; i < wordInLetters.length; i++) {
  correctGuess.push('_')
}

console.log('Bienvenido al Ahorcado!! Para salvarte debes adivinar la palabra secreta escogiendo con cuidado cada letra, solo tienes 6 oportunidades para equivocarte!\n')

while (error < 6 && correctLetters > 0){
  let letterUser = prompt('Ingrese una letra: ')
      if (wordInLetters.includes(letterUser.toLowerCase()) == true) {
        const index = indexOfLetters(wordInLetters, letterUser)
        for (let i = 0; i < index.length; i++){
          correctGuess[index[i]] = letterUser
        }
        correctLetters -= index.length
        console.log(...correctGuess)
        if (correctLetters == 0){
          console.log('\nGanaste!! Felicidades!!')
        }
          } else {
            theMan += manError[error]
            error++
            console.log('---|')
            console.log(theMan)
            if (error == 6) {
              console.log('\nPerdiste!! Has muerto ahorcado!!')
            }
          }
        }
      }

hangMan()